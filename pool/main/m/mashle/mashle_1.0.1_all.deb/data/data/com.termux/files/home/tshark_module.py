from flask import request
from markupsafe import escape
from pathlib import Path
import subprocess

def tshark_page():
    file_path = request.args.get("file", "").strip()

    if not file_path:
        result = "<p>Choisissez un fichier .pcap ou .pcapng.</p>"
    else:
        path = Path(file_path).expanduser()

        if not path.is_file():
            result = "<p>Fichier introuvable.</p>"
        elif path.suffix.lower() not in (".pcap", ".pcapng"):
            result = "<p>Format refusé : utilisez .pcap ou .pcapng.</p>"
        else:
            try:
                packets = subprocess.run(
                    ["tshark", "-r", str(path), "-c", "50"],
                    capture_output=True,
                    text=True,
                    timeout=30
                )

                protocols = subprocess.run(
                    ["tshark", "-r", str(path), "-T", "fields", "-e", "_ws.col.Protocol"],
                    capture_output=True,
                    text=True,
                    timeout=30
                )

                lines = [x.strip() for x in protocols.stdout.splitlines() if x.strip()]
                counts = {}
                for proto in lines:
                    counts[proto] = counts.get(proto, 0) + 1

                summary = "<h3>Résumé</h3>"
                summary += f"<p>Paquets analysés : <strong>{len(lines)}</strong></p>"

                if counts:
                    summary += "<ul>"
                    for proto, count in sorted(counts.items(), key=lambda x: (-x[1], x[0])):
                        summary += f"<li>{escape(proto)} : {count}</li>"
                    summary += "</ul>"

                output = packets.stdout + packets.stderr
                result = summary + "<h3>Paquets</h3>"
                result += f"<pre style='white-space:pre-wrap'>{escape(output)}</pre>"

            except Exception as e:
                result = f"<p>Erreur : {escape(str(e))}</p>"

    return f"""
<h2>Analyse TShark</h2>
<p>Analyse locale de captures réseau.</p>

<form method="get">
<input name="file" value="{escape(file_path)}"
       placeholder="Chemin du fichier .pcap"
       style="width:70%">
<button type="submit">Analyser</button>
</form>

{result}
"""
