import os
import urllib.parse
import html
# MASHLE_INSPIREFACE_PATH
import sys
sys.path.insert(0,'/data/data/com.termux/files/home/InspireFace/python')
import sys; sys.path.insert(0,'/data/data/com.termux/files/home')
from ftk_module import ftk_page, ftk_analyze_route
from autopsy_module import autopsy_page, autopsy_analyze
from malware_module import malware_page, run_malware_scan
from yara_module import yara_page
from exiftool_module import exiftool_page
from tshark_module import tshark_page
from werkzeug.utils import secure_filename
from flask import Flask, request, redirect, url_for
from wireshark_module import wireshark_page, wireshark_analyze
from phonia_module import phonia_page, phonia_analyze, phonia_capture
from markupsafe import escape
from pathlib import Path
import json
from datetime import datetime
import subprocess
# ============================================================
# MASHLE INTERPRETER — traduction locale des résultats
# ============================================================

def mashle_interpret(module, text):
    """Transforme une sortie technique en explication française lisible."""
    import re

    raw=str(text or "").strip()
    m=str(module or "").lower()

    if not raw:
        return "Aucun résultat technique à interpréter."

    lines=[x.strip() for x in raw.splitlines() if x.strip()]
    explanations=[]

    if "nmap" in m:
        ports=[]
        for line in lines:
            x=re.search(r'(\d+)/(tcp|udp)\s+open\s+([^\s]+)',line,re.I)
            if x:
                ports.append(f"le port {x.group(1)} ({x.group(3)}) est ouvert")
        if ports:
            explanations.append("Le scan réseau a détecté " + ", ".join(ports) + ".")
        else:
            explanations.append("Le scan réseau n'a pas identifié de port ouvert dans les résultats fournis.")

    elif "yara" in m:
        matches=[x for x in lines if "match" in x.lower() or "rule" in x.lower()]
        if matches:
            explanations.append("L'analyse YARA a trouvé des correspondances avec au moins une règle.")
            explanations.append("Une correspondance est un signal à examiner et ne signifie pas automatiquement que le fichier est malveillant.")
        else:
            explanations.append("Aucune correspondance YARA évidente n'apparaît dans les résultats.")

    elif "exif" in m:
        explanations.append("ExifTool a extrait les métadonnées disponibles du fichier.")
        if any("GPS" in x.upper() or "LATITUDE" in x.upper() or "LONGITUDE" in x.upper() for x in lines):
            explanations.append("Des informations de localisation semblent présentes dans les métadonnées.")

    elif "inspire" in m or "face" in m:
        if re.search(r'visages?\s*d[ée]tect[ée]s?\s*:\s*0',raw,re.I):
            explanations.append("L'analyse s'est terminée correctement, mais aucun visage n'a été détecté dans l'image.")
        elif re.search(r'visages?\s*d[ée]tect[ée]s?\s*:\s*[1-9]',raw,re.I):
            explanations.append("L'analyse a détecté au moins un visage dans l'image.")
        else:
            explanations.append("L'image a été transmise au module d'analyse faciale et le résultat technique est disponible.")

    elif "tshark" in m or "wireshark" in m:
        explanations.append("L'analyse du trafic réseau a été effectuée. Les lignes affichées correspondent aux paquets ou informations réseau observés.")

    elif "malware" in m:
        explanations.append("L'analyse de sécurité a examiné le fichier à la recherche d'indicateurs suspects.")
        explanations.append("Un indicateur suspect doit être vérifié avant de conclure qu'un fichier est malveillant.")

    elif "autopsy" in m or "ftk" in m:
        explanations.append("L'analyse forensique a traité les éléments disponibles dans la source examinée.")

    elif "phonia" in m:
        explanations.append("Le module audio a traité l'élément fourni et produit les résultats techniques affichés.")

    else:
        explanations.append("Le module a terminé son traitement. Les lignes ci-dessus constituent les résultats techniques disponibles.")

    return "\n".join("• "+x for x in explanations)


def mashle_interpretation_block(module, text):
    explanation=mashle_interpret(module,text)
    return (
        "\n"
        "════════════════════════════════════\n"
        "        🤖 INTERPRÉTATION MASHLE\n"
        "════════════════════════════════════\n"
        f"{explanation}\n"
        "════════════════════════════════════\n"
    )


app = Flask(__name__)

# === MASHLE CMATRIX MANAGER ===
import subprocess
import signal

_MASHLE_CMATRIX_PROC = None

def mashle_cmatrix_start():
    global _MASHLE_CMATRIX_PROC
    if _MASHLE_CMATRIX_PROC is not None and _MASHLE_CMATRIX_PROC.poll() is None:
        return True
    try:
        _MASHLE_CMATRIX_PROC = subprocess.Popen(
            ["cmatrix", "-b"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        return True
    except Exception:
        _MASHLE_CMATRIX_PROC = None
        return False

def mashle_cmatrix_stop():
    global _MASHLE_CMATRIX_PROC
    if _MASHLE_CMATRIX_PROC is not None:
        try:
            if _MASHLE_CMATRIX_PROC.poll() is None:
                _MASHLE_CMATRIX_PROC.send_signal(signal.SIGTERM)
                _MASHLE_CMATRIX_PROC.wait(timeout=2)
        except Exception:
            try:
                _MASHLE_CMATRIX_PROC.kill()
            except Exception:
                pass
    _MASHLE_CMATRIX_PROC = None
    return True



DATA = Path.home() / "mashle_data.json"

def load_data():
    if DATA.exists():
        try:
            return json.loads(DATA.read_text(encoding="utf-8"))
        except Exception:
            return []
    return []

def save_data(data):
    DATA.write_text(
        json.dumps(data, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )

def page(title, content):
    return f"""
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>MASHLE — {escape(title)}</title>
<style>
body {{
    margin:0;
    font-family:Arial,sans-serif;
    background:#101114;
    color:#eee;
}}
header {{
    padding:24px;
    background:#17191e;
    border-bottom:1px solid #30333a;
}}
header h1 {{ margin:0; letter-spacing:6px; }}
nav {{ margin-top:15px; }}
nav a {{
    color:#ddd;
    text-decoration:none;
    margin-right:16px;
}}
main {{ padding:24px; max-width:1100px; margin:auto; }}
.cards {{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
    gap:15px;
}}
.card {{
    background:#191b20;
    border:1px solid #30333a;
    border-radius:12px;
    padding:20px;
}}
.number {{ font-size:32px; font-weight:bold; }}
table {{
    width:100%;
    border-collapse:collapse;
    margin-top:20px;
}}
th,td {{
    padding:12px;
    border-bottom:1px solid #30333a;
    text-align:left;
}}
input,select,button {{
    padding:11px;
    margin:5px 0;
    border-radius:7px;
    border:1px solid #444;
}}
button {{ cursor:pointer; }}
form {{ margin-top:20px; }}
</style>
</head>
<body>
<header>
<h1>MASHLE</h1>
<div>CYBER INTELLIGENCE LAB</div>
<nav>
<a href="/">Dashboard</a>
<a href="/intel">Renseignements</a>
<a href="/search">Recherche</a>
</nav>
</header>
<main>
{content}
</main>
</body>
</html>
"""


# ==================== MASHLE CENTRAL EXECUTION HOOKS ====================

MASHLE_INTERPRETER_ROUTES = {
    "/nmap/scan": "Nmap",
    "/yara": "YARA",
    "/exiftool": "ExifTool",
    "/tshark": "TShark",
    "/phonia/analyze": "Phonia",
    "/phonia/capture": "Phonia",
    "/wireshark/analyze": "Wireshark",
    "/malware/scan": "Malware Lab",
    "/autopsy/analyze": "Autopsy",
    "/ftk/analyze": "FTK",
    "/face-lab/analyze": "InspireFace / Face Lab",
}

@app.before_request
def mashle_central_start():
    if request.path in MASHLE_INTERPRETER_ROUTES:
        try:
            mashle_cmatrix_start()
        except Exception:
            pass

@app.after_request
def mashle_central_finish(response):
    module=MASHLE_INTERPRETER_ROUTES.get(request.path)

    if not module:
        return response

    try:
        mashle_cmatrix_stop()
    except Exception:
        pass

    try:
        if response.is_json:
            data=response.get_json(silent=True)

            if isinstance(data,dict):
                raw_parts=[]

                for key in ("output","result","error","status"):
                    if key in data:
                        raw_parts.append(str(data[key]))

                raw="\n".join(raw_parts)

                data["mashle_interpretation"]=mashle_interpret(module,raw)
                response.set_data(
                    json.dumps(data,ensure_ascii=False)
                )
                response.content_type="application/json; charset=utf-8"

            return response

        html=response.get_data(as_text=True)

        raw=""
        import re as _re

        matches=_re.findall(
            r"<pre[^>]*>(.*?)</pre>",
            html,
            flags=_re.I|_re.S
        )

        if matches:
            raw=_re.sub("<[^>]+>"," ",matches[-1])
            raw=escape(raw)

        explanation=mashle_interpretation_block(module,raw)

        if "</body>" in html.lower():
            pos=html.lower().rfind("</body>")
            html=html[:pos]+explanation+html[pos:]

        response.set_data(html)

    except Exception:
        pass

    return response

@app.route("/")
def home():
    data = load_data()

    total = len(data)
    high = sum(1 for x in data if x.get("priority") == "Élevée")
    medium = sum(1 for x in data if x.get("priority") == "Moyenne")
    low = sum(1 for x in data if x.get("priority") == "Faible")

    content = f"""
<h2>Tableau de bord</h2>

<div class="cards">
<div class="card">
<div>Renseignements</div>
<div class="number">{total}</div>
</div>

<div class="card">
<div>Priorité élevée</div>
<div class="number">{high}</div>
</div>

<div class="card">
<div>Priorité moyenne</div>
<div class="number">{medium}</div>
</div>

<div class="card">
<div>Priorité faible</div>
<div class="number">{low}</div>
</div>
</div>

<div class="card" style="margin-top:20px">
<h3>Modules</h3>
<p>🔎 Renseignements — gestion des observations</p>
<p>🌐 Recherche — recherche locale</p>
<p>📊 Dashboard — statistiques récapitulatives</p>
<p>📜 Données — stockage local</p>
</div>
"""

    return page("Dashboard", content)

@app.route("/intel")
def intel():
    q = request.args.get("q", "").strip().lower()
    data = load_data()

    if q:
        filtered = []

        for item in data:
            searchable = " ".join([
                str(item.get("type", "")),
                str(item.get("value", "")),
                str(item.get("priority", "")),
                str(item.get("note", "")),
                str(item.get("date", ""))
            ]).lower()

            if q in searchable:
                filtered.append(item)

        data = filtered

    rows = ""

    for item in data:
        rows += f"""
<tr>
<td>{escape(item.get("type", ""))}</td>
<td>{escape(item.get("value", ""))}</td>
<td>{escape(item.get("priority", ""))}</td>
<td>{escape(item.get("note", ""))}</td>
<td>{escape(item.get("date", ""))}</td>
</tr>
"""

    content = f"""
<h2>Renseignements</h2>

<form method="get">
<input
    name="q"
    value="{escape(q)}"
    placeholder="Rechercher dans les renseignements..."
>
<button type="submit">Filtrer</button>
</form>

<form method="post" action="/intel/add">
<input name="type" placeholder="Type : IP, domaine, hash...">
<input name="value" placeholder="Valeur">
<select name="priority">
<option>Faible</option>
<option>Moyenne</option>
<option>Élevée</option>
</select>
<input name="note" placeholder="Observation">
<button type="submit">Ajouter</button>
</form>

<p>
<strong>{len(data)}</strong> renseignement(s) trouvé(s).
</p>

<table>
<tr>
<th>Type</th>
<th>Valeur</th>
<th>Priorité</th>
<th>Observation</th>
<th>Date</th>
</tr>
{rows}
</table>
"""

    return page("Renseignements", content)


@app.route("/intel/add", methods=["POST"])
def intel_add():
    data = load_data()

    data.append({
        "type": request.form.get("type", ""),
        "value": request.form.get("value", ""),
        "priority": request.form.get("priority", "Faible"),
        "note": request.form.get("note", ""),
        "date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    })

    save_data(data)
    return redirect(url_for("intel"))
@app.route("/nmap")
def nmap_page():
    return page("Nmap", """
<h2>Analyse réseau — Nmap</h2>
<p>Utilisez uniquement une cible de votre propre réseau ou laboratoire.</p>

<form method="post" action="/nmap/scan">
<input name="target" placeholder="Exemple : 192.168.100.10" required>
<button type="submit">Lancer l'analyse</button>
</form>
""")

@app.route("/nmap/scan", methods=["POST"])
def nmap_scan():
    target = request.form.get("target", "").strip()

    if not target:
        return redirect(url_for("nmap_page"))

    try:
        result = subprocess.run(
            ["nmap", "-sV", "--", target],
            capture_output=True,
            text=True,
            timeout=60
        )
        output = result.stdout + result.stderr
    except Exception as e:
        output = str(e)

    return page("Résultat Nmap", f"""
<h2>Résultat Nmap</h2>
<pre style="white-space:pre-wrap">{escape(output)}</pre>
<p><a href="/nmap">← Nouvelle analyse</a></p>
""")
@app.route("/search")
def search():
    q = request.args.get("q", "").strip().lower()

    results = []

    if q:
        # Recherche dans les renseignements
        for item in load_data():
            searchable = " ".join(
                str(value)
                for value in item.values()
            ).lower()

            if q in searchable:
                results.append({
                    "source": "Intel",
                    "title": item.get("value", ""),
                    "details": (
                        f"{item.get('type', '')} — "
                        f"{item.get('priority', '')} — "
                        f"{item.get('note', '')}"
                    )
                })

        # Recherche dans les rapports Malware Lab
        reports_dir = (
            Path.home()
            / "mashle_malware_lab"
            / "reports"
        )

        if reports_dir.exists():
            for report_file in reports_dir.glob("*.json"):
                try:
                    report = json.loads(
                        report_file.read_text(
                            encoding="utf-8"
                        )
                    )

                    searchable = json.dumps(
                        report,
                        ensure_ascii=False
                    ).lower()

                    if q in searchable:
                        results.append({
                            "source": "Malware Lab",
                            "title": report.get(
                                "file",
                                report_file.name
                            ),
                            "details": (
                                "Classification : "
                                + str(
                                    report.get(
                                        "assessment",
                                        {}
                                    ).get(
                                        "classification",
                                        "Inconnue"
                                    )
                                )
                            )
                        })

                except Exception:
                    continue

    rows = ""

    for result in results:
        rows += f"""
<div class="card">
    <strong>{escape(result["source"])}</strong>
    <h3>{escape(result["title"])}</h3>
    <p>{escape(result["details"])}</p>
</div>
"""

    content = f"""
<h2>Recherche globale</h2>

<form method="get">
<input
    name="q"
    value="{escape(q)}"
    placeholder="Rechercher dans MASHLE..."
>
<button type="submit">Rechercher</button>
</form>

<p>
<strong>{len(results)}</strong> résultat(s)
</p>

{rows or "<p>Aucun résultat.</p>"}
"""

    return page("Recherche", content)


@app.route("/yara")
def yara():
    return yara_page()

@app.route("/exiftool")
def exiftool():
    return exiftool_page()

@app.route("/tshark")
def tshark():
    return tshark_page()


@app.route("/phonia")
def phonia():
    return phonia_page()

@app.route("/phonia/analyze", methods=["POST"])
def phonia_analyze_route():
    return phonia_analyze()

@app.route("/phonia/capture", methods=["POST"])
def phonia_capture_route():
    return phonia_capture()


@app.route("/wireshark")
def wireshark():
    return wireshark_page()

@app.route("/wireshark/analyze", methods=["POST"])
def wireshark_analyze_route():
    return wireshark_analyze()

@app.route("/malware")
def malware():
    return malware_page()


@app.route("/malware/scan", methods=["POST"])
def malware_scan():
    file_path = request.form.get("file", "").strip()

    output = run_malware_scan(file_path)

    return f"""
    <html>
    <body>
        <h1>MALWARE LAB — RÉSULTAT</h1>
        <pre>{escape(output)}</pre>
        <p><a href="/malware">← Retour au Malware Lab</a></p>
    </body>
    </html>
    """



@app.route("/autopsy")
def autopsy():
    return autopsy_page()


@app.route("/autopsy/analyze", methods=["POST"])
def autopsy_analyze_route():
    return autopsy_analyze()


@app.route("/ftk")
def ftk():
    return ftk_page()


@app.route("/ftk/analyze", methods=["POST"])
def ftk_analyze():
    return ftk_analyze_route()




# ==================== MASHLE FACE LAB / CONNECTOR ====================
MASHLE_FACE_DIR = Path(os.path.expanduser("~/mashle_face_lab"))
MASHLE_FACE_UPLOADS = Path(os.path.expanduser("~/mashle_face_lab/uploads"))
MASHLE_FACE_REPORTS = Path(os.path.expanduser("~/mashle_face_lab/reports"))
for _d in (MASHLE_FACE_DIR,MASHLE_FACE_UPLOADS,MASHLE_FACE_REPORTS):
    _d.mkdir(parents=True,exist_ok=True)

FACE_ENGINES=[
    ("Google Lens","https://lens.google.com/"),
    ("Google Images","https://images.google.com/"),
    ("Bing Visual Search","https://www.bing.com/visualsearch"),
    ("TinEye","https://tineye.com/"),
    ("Yandex Images","https://yandex.com/images/")
]

def mashle_face_hash(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for c in iter(lambda:f.read(1024*1024),b""):
            h.update(c)
    return h.hexdigest()

def mashle_png_rgb(path):
    import zlib
    import numpy as np
    b=Path(path).read_bytes()
    if b[:8]!=b"\x89PNG\r\n\x1a\n":
        raise ValueError("Format PNG attendu")
    pos=8; raw=b""; w=h=ct=None
    while pos<len(b):
        n=int.from_bytes(b[pos:pos+4],"big")
        typ=b[pos+4:pos+8]
        dat=b[pos+8:pos+8+n]
        pos+=12+n
        if typ==b"IHDR":
            w=int.from_bytes(dat[:4],"big")
            h=int.from_bytes(dat[4:8],"big")
            bd=dat[8]; ct=dat[9]
            if bd!=8 or ct not in (2,6):
                raise ValueError("PNG RGB/RGBA 8-bit requis")
        elif typ==b"IDAT":
            raw+=dat
        elif typ==b"IEND":
            break
    dec=zlib.decompress(raw)
    ch=3 if ct==2 else 4
    stride=w*ch
    out=[]; off=0
    prev=np.zeros(stride,dtype=np.uint8)
    for _ in range(h):
        f=dec[off]; off+=1
        cur=np.frombuffer(dec[off:off+stride],dtype=np.uint8).copy()
        off+=stride
        left=np.r_[np.zeros(ch,dtype=np.uint8),cur[:-ch]]
        if f==1: cur=(cur+left)&255
        elif f==2: cur=(cur+prev)&255
        elif f==3: cur=(cur+((left.astype(np.uint16)+prev.astype(np.uint16))//2).astype(np.uint8))&255
        elif f==4:
            ul=np.r_[np.zeros(ch,dtype=np.uint8),prev[:-ch]]
            pp=left.astype(np.int16)+prev.astype(np.int16)-ul.astype(np.int16)
            pa=np.abs(pp-left.astype(np.int16)); pb=np.abs(pp-prev.astype(np.int16)); pc=np.abs(pp-ul.astype(np.int16))
            pr=np.where((pa<=pb)&(pa<=pc),left,np.where(pb<=pc,prev,ul))
            cur=(cur+pr.astype(np.uint8))&255
        elif f!=0: raise ValueError("Filtre PNG non supporté")
        out.append(cur); prev=cur
    return np.vstack(out).reshape(h,w,ch)[:,:,:3].copy(),w,h

def mashle_inspireface(path):
    r={"status":"error","faces":0,"features":0,"error":None}
    try:
        import sys
        import numpy as np
        sys.path.insert(0,str(Path.home()/"InspireFace/python"))
        import inspireface as isf
        model=Path.home()/"InspireFace/test_res/pack/Pikachu"
        if not isf.query_launch_status() and not isf.launch(resource_path=str(model)):
            r["error"]="InspireFace launch failed"
            return r
        rgb,w,h=mashle_png_rgb(path)
        stream=isf.ImageStream.load_from_ndarray(rgb,w,h,isf.HF_STREAM_RGB,isf.HF_CAMERA_ROTATION_0)
        session=isf.InspireFaceSession(
            isf.HF_ENABLE_FACE_RECOGNITION,
            isf.HF_DETECT_MODE_ALWAYS_DETECT
        )
        session.set_detection_confidence_threshold(0.5)
        faces=session.face_detection(stream)
        r["status"]="ok"
        r["faces"]=len(faces)
        for face in faces:
            try:
                if session.face_feature_extract(stream,face) is not None:
                    r["features"]+=1
            except Exception:
                pass
        session.release()
        stream.release()
    except Exception as e:
        r["error"]=repr(e)
    return r

class FaceSearchConnector:
    def __init__(self):
        self.engines=FACE_ENGINES

    def status(self):
        return [
            {
                "name":name,
                "url":url,
                "status":"ready",
                "mode":"official_public_interface"
            }
            for name,url in self.engines.items()
        ]

    def build_search(self,query=""):
        q=(query or "").strip()
        google="https://www.google.com/search?q="+urllib.parse.quote(q)
        copilot="https://copilot.microsoft.com/"
        return {
            "query":q,
            "google_search":google,
            "copilot":copilot
        }

face_search_connector=FaceSearchConnector()

@app.route("/face-lab")
def mashle_face_lab():
    engines="".join(f'<li><a href="{u}" target="_blank">{html.escape(n)}</a> — prêt</li>' for n,u in FACE_ENGINES.items())
    return page("MASHLE Face Lab",f"""
    <h1>🧠 MASHLE Face Lab</h1>
    <p>Analyse locale + connecteur de recherche visuelle.</p>
    <form action="/face-lab/analyze" method="post" enctype="multipart/form-data">
      <input type="file" name="image" accept=".png,.jpg,.jpeg" required>
      <button type="submit">Ajouter et analyser</button>
    </form>
    <h2>Moteurs connectés</h2><ul>{engines}</ul>
    """)

@app.route("/face-lab/analyze",methods=["POST"])
def mashle_face_lab_analyze():
    mashle_cmatrix_start()
    f=request.files.get("image")
    if not f or not f.filename:
        return page("Face Lab","<h2>Aucune image.</h2><a href='/face-lab'>Retour</a>")
    name=secure_filename(f.filename) or "image.png"
    out=Path(MASHLE_FACE_UPLOADS)/(hashlib.sha256(os.urandom(32)).hexdigest()[:16]+"_"+name)
    f.save(out)
    local=mashle_inspireface(out)
    connector=FaceSearchConnector().status()
    report={
        "module":"MASHLE Face Lab",
        "date":datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
        "input":out.name,
        "sha256":mashle_face_hash(out),
        "inspireface":local,
        "web_connector":connector
    }
    rp=Path(MASHLE_FACE_REPORTS)/(out.stem+".json")
    rp.write_text(json.dumps(report,ensure_ascii=False,indent=2))
    rows="".join(f'<li><b>{html.escape(str(x.get("name", x) if isinstance(x, dict) else x))}</b> : {html.escape(str(x.get("status", "ready") if isinstance(x, dict) else "ready"))}</li>' for x in (connector.get("engines", []) if isinstance(connector, dict) else connector))
    err=f'<p>Erreur locale : {html.escape(str(local["error"]))}</p>' if local["error"] else ""
    return page("Face Lab — Résultat",f"""
    <h1>🧠 Face Lab</h1>
    <p><b>Image :</b> {html.escape(out.name)}</p>
    <p><b>SHA-256 :</b> <code>{report["sha256"]}</code></p>
    <h2>InspireFace</h2>
    <p>Statut : <b>{local["status"]}</b></p>
    <p>Visages détectés : <b>{local["faces"]}</b></p>
    <p>Features extraites : <b>{local["features"]}</b></p>{err}
    <h2>Connecteur moteurs</h2><ul>{rows}</ul>
    <p><a href="/face-lab">← Nouvelle analyse</a></p>
    """)

# ================== FIN MASHLE FACE LAB ==================


# ==================== MASHLE FACE LAB ====================
import os, json, hashlib, datetime
MASHLE_FACE_DIR = Path(os.path.expanduser("~/mashle_face_lab"))
MASHLE_FACE_UPLOADS = Path(os.path.expanduser("~/mashle_face_lab/uploads"))
MASHLE_FACE_REPORTS = Path(os.path.expanduser("~/mashle_face_lab/reports"))
os.makedirs(MASHLE_FACE_UPLOADS,exist_ok=True)
os.makedirs(MASHLE_FACE_REPORTS,exist_ok=True)

FACE_ENGINES={
    "Google Lens":"https://lens.google.com/",
    "Google Images":"https://images.google.com/",
    "Bing Visual Search":"https://www.bing.com/visualsearch",
    "TinEye":"https://tineye.com/",
    "Yandex Images":"https://yandex.com/images/",
    "Google Search":"https://www.google.com/search",
    "Microsoft Copilot":"https://copilot.microsoft.com/"
}

def mashle_face_hash(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):
            h.update(chunk)
    return h.hexdigest()

def _mashle_png_rgb(path):
    """Charge une image locale JPG/JPEG/PNG/WEBP et retourne RGB, largeur, hauteur."""
    try:
        from PIL import Image
    except Exception as e:
        raise RuntimeError("Pillow requis pour lire les images: " + str(e))

    img=Image.open(path)
    img=img.convert("RGB")
    w,h=img.size
    rgb=img.tobytes()
    return rgb,w,h

def mashle_inspireface(path):
    import numpy as np
    from inspireface.modules import inspireface as isf

    rgb,w,h=_mashle_png_rgb(path)

    resource=os.path.expanduser("~/InspireFace/test_res/pack/Pikachu")
    if not isf.launch(resource_path=resource):
        raise RuntimeError("InspireFace launch failed")

    stream=isf.ImageStream.load_from_ndarray(
        rgb,w,h,
        isf.HF_STREAM_RGB,
        isf.HF_CAMERA_ROTATION_0
    )

    session=isf.InspireFaceSession(
        isf.HF_ENABLE_FACE_RECOGNITION,
        isf.HF_DETECT_MODE_ALWAYS_DETECT
    )

    faces=session.face_detection(stream)
    count=len(faces) if faces is not None else 0

    features=0
    if count:
        try:
            f=session.face_feature_extract(stream,faces[0])
            features=1 if f is not None else 0
        except Exception:
            features=0

    return {
        "status":"ok",
        "image_width":int(w),
        "image_height":int(h),
        "faces":int(count),
        "features":int(features),
        "sha256":mashle_face_hash(path),
        "error":None
    }

class FaceSearchConnector:
    def __init__(self):
        self.engines=FACE_ENGINES
    def status(self):
        return [{"name":k,"url":v,"status":"ready"} for k,v in self.engines.items()]

face_search_connector=FaceSearchConnector()

@app.route("/face-lab",methods=["GET"])
def face_lab():
    engines="".join(
        f'<li><a href="{u}" target="_blank" rel="noopener">{html.escape(n)}</a> — prêt</li>'
        for n,u in FACE_ENGINES.items()
    )

    return f"""<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>MASHLE Face Lab</title>
<style>
body{{font-family:system-ui;background:#111;color:#eee;max-width:900px;margin:30px auto;padding:20px}}
.card{{background:#1c1c1c;padding:20px;border-radius:14px;margin:15px 0}}
button{{padding:12px 18px;border:0;border-radius:8px;cursor:pointer}}
input{{padding:10px;margin:6px 0;width:100%;box-sizing:border-box}}
li{{margin:10px 0}}
a{{color:#8ab4ff}}
pre{{white-space:pre-wrap;overflow:auto}}
</style>
</head>
<body>
<h1>🔎 MASHLE Face Lab</h1>

<div class="card">
<h2>Analyse locale</h2>
<form method="post" action="/face-lab/analyze" enctype="multipart/form-data">
<input type="file" name="image" accept="image/png,image/jpeg" required>
<input type="text" name="query" placeholder="Terme à rechercher publiquement (optionnel)">
<button type="submit">Analyser</button>
</form>
</div>

<div class="card">
<h2>🌐 Recherche visuelle</h2>
<ul>{engines}</ul>
</div>

<div class="card">
<h2>📄 MASHLE Report</h2>
<p>L'analyse locale et les liens de recherche publique sont enregistrés dans un rapport JSON.</p>
</div>
</body>
</html>"""

@app.route("/face-lab/analyze",methods=["POST"])
def face_lab_analyze():
    from flask import request,jsonify

    f=request.files.get("image")
    if not f or not f.filename:
        return jsonify({"status":"error","error":"image manquante"}),400

    name=os.path.basename(f.filename)
    path=os.path.join(MASHLE_FACE_UPLOADS,name)
    f.save(path)

    try:
        result=mashle_inspireface(path)
    except Exception as e:
        result={
            "status":"error",
            "faces":0,
            "features":0,
            "error":str(e),
            "sha256":mashle_face_hash(path)
        }

    # Recherche publique préparée à partir d'un terme fourni,
    # sans déduire automatiquement l'identité depuis le visage.
    query=request.form.get("query","").strip()

    result["module"]="MASHLE Face Lab"
    result["input"]=name
    result["date"]=datetime.datetime.now().isoformat()
    result["public_search"]=face_search_connector.build_search(query)
    result["engines"]=face_search_connector.status()

    report=os.path.join(
        MASHLE_FACE_REPORTS,
        hashlib.sha256((name+result["date"]).encode()).hexdigest()[:16]+".json"
    )

    with open(report,"w",encoding="utf-8") as out:
        json.dump(result,out,ensure_ascii=False,indent=2)

    result["report"]=report
    return jsonify(result)

# ================== END MASHLE FACE LAB ==================


def mashle_boot_screen():
    import os
    import time

    os.system("clear")

    art = r"""
╔══════════════════════════════════════════════════════╗
║                                                      ║
║                    M A S H L E                       ║
║          DIGITAL • INTELLIGENCE • OPERATION          ║
║                                                      ║
║                 ┌──────────────┐                     ║
║                 │    ◉    ◉    │                     ║
║                 │      ──      │                     ║
║                 │   MASHLE     │                     ║
║                 └──────────────┘                     ║
║                                                      ║
║        >>> SYSTEME MASHLE : INITIALISATION          ║
║        >>> SECURITE ................. [OK]          ║
║        >>> MODULES .................. [12/12]       ║
║        >>> INSPIREFACE .............. [OK]          ║
║        >>> FACE LAB ................. [OK]          ║
║        >>> CMATRIX .................. [OK]          ║
║                                                      ║
╚══════════════════════════════════════════════════════╝
"""

    print("\033[92m" + art + "\033[0m")

    for i in range(10, 0, -1):
        filled = 11 - i
        bar = "█" * filled + "░" * (10 - filled)
        print(
            f"\r\033[92m>>> INITIALISATION [{bar}] {i:02d}s\033[0m",
            end="",
            flush=True
        )
        time.sleep(1)

    print("\n\033[92m>>> MASHLE EST PRET.\033[0m\n")
    time.sleep(0.5)
    os.system("clear")


if __name__ == "__main__":
    mashle_boot_screen()
    app.run(host="127.0.0.1", port=5001, debug=False)
