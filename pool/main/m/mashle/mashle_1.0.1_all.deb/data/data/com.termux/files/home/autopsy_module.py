from pathlib import Path
import subprocess
import hashlib
import json
from datetime import datetime


BASE_DIR = Path.home() / "mashle_forensics"
REPORT_DIR = BASE_DIR / "reports"
REPORT_DIR.mkdir(parents=True, exist_ok=True)


def run_cmd(command, timeout=60):
    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=timeout
        )

        return {
            "returncode": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr
        }

    except Exception as e:
        return {
            "returncode": -1,
            "stdout": "",
            "stderr": str(e)
        }


def sha256_file(path):
    h = hashlib.sha256()

    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)

    return h.hexdigest()


def forensic_analyze(image_path):
    image = Path(image_path).expanduser().resolve()

    if not image.exists():
        raise FileNotFoundError(f"Preuve introuvable : {image}")

    if not image.is_file():
        raise ValueError("La preuve doit être un fichier.")

    report = {
        "tool": "MASHLE Autopsy / Sleuth Kit",
        "engine": "The Sleuth Kit",
        "version": "4.14.0",
        "timestamp": datetime.now().isoformat(),
        "evidence": str(image),
        "size_bytes": image.stat().st_size,
        "sha256": sha256_file(image),
        "partitions": "",
        "filesystem": "",
        "files": "",
        "metadata": ""
    }

    # Analyse des partitions
    result = run_cmd(["mmls", str(image)])
    report["partitions"] = result["stdout"] or result["stderr"]

    # Analyse du système de fichiers
    result = run_cmd(["fsstat", str(image)])
    report["filesystem"] = result["stdout"] or result["stderr"]

    # Liste des fichiers
    result = run_cmd(["fls", "-r", str(image)])
    report["files"] = result["stdout"] or result["stderr"]

    # Métadonnées générales
    result = run_cmd(["istat", str(image), "2"])
    report["metadata"] = result["stdout"] or result["stderr"]

    report_name = image.stem + "_forensic.json"
    report_path = REPORT_DIR / report_name

    report_path.write_text(
        json.dumps(report, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )

    return report, report_path


def autopsy_page():
    return """
    <html>
    <head>
        <title>MASHLE — Autopsy / Sleuth Kit</title>
        <style>
            body {
                background:#0b0b0b;
                color:#eee;
                font-family:Arial,sans-serif;
                padding:30px;
            }

            .box {
                max-width:900px;
                margin:auto;
                background:#151515;
                padding:25px;
                border-radius:12px;
            }

            input, button {
                padding:12px;
                margin-top:10px;
                width:100%;
                box-sizing:border-box;
            }

            button {
                cursor:pointer;
            }

            pre {
                background:#050505;
                padding:15px;
                overflow:auto;
                white-space:pre-wrap;
            }

            .ok {
                color:#6cff9b;
            }

            .err {
                color:#ff7777;
            }
        </style>
    </head>

    <body>
        <div class="box">

            <h1>AUTOPSY / SLEUTH KIT</h1>

            <p>
                MASHLE Forensic Case — The Sleuth Kit 4.14.0
            </p>

            <form method="POST" action="/autopsy/analyze">

                <label>
                    Chemin de l'image disque / preuve :
                </label>

                <input
                    type="text"
                    name="image"
                    placeholder="/sdcard/Download/evidence.dd"
                    required
                >

                <button type="submit">
                    ANALYSER LA PREUVE
                </button>

            </form>

        </div>
    </body>
    </html>
    """


def autopsy_analyze():
    from flask import request

    image = request.form.get("image", "").strip()

    if not image:
        return "<h3 class='err'>Aucune preuve indiquée.</h3>"

    try:
        report, report_path = forensic_analyze(image)

        return f"""
        <html>
        <body style="background:#0b0b0b;color:#eee;font-family:Arial;padding:30px">

        <h1 class="ok">ANALYSE TERMINÉE</h1>

        <p><b>Preuve :</b> {report["evidence"]}</p>
        <p><b>Taille :</b> {report["size_bytes"]} octets</p>
        <p><b>SHA-256 :</b> {report["sha256"]}</p>

        <h2>Partitions — mmls</h2>
        <pre>{report["partitions"]}</pre>

        <h2>Système de fichiers — fsstat</h2>
        <pre>{report["filesystem"]}</pre>

        <h2>Fichiers — fls</h2>
        <pre>{report["files"][:20000]}</pre>

        <h2>Métadonnées — istat</h2>
        <pre>{report["metadata"]}</pre>

        <p>
            Rapport :
            <code>{report_path}</code>
        </p>

        </body>
        </html>
        """

    except Exception as e:
        return f"""
        <html>
        <body style="background:#0b0b0b;color:#eee;font-family:Arial;padding:30px">
        <h1 style="color:#ff7777">ERREUR FORENSIC</h1>
        <pre>{e}</pre>
        </body>
        </html>
        """
