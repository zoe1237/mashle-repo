from pathlib import Path
from flask import request
from markupsafe import escape
import subprocess
import json
import html

PHONIA_DIR = Path.home() / "mashle_phonia"
REPORTS = PHONIA_DIR / "reports"

REPORTS.mkdir(parents=True, exist_ok=True)


def run_tshark(args, timeout=120):
    try:
        result = subprocess.run(
            ["tshark"] + args,
            capture_output=True,
            text=True,
            timeout=timeout
        )

        return result.stdout, result.stderr

    except subprocess.TimeoutExpired:
        return "", "Analyse interrompue : délai dépassé."

    except Exception as exc:
        return "", str(exc)


def analyze_pcap(path):
    path = Path(path).expanduser().resolve()

    if not path.is_file():
        return {"error": "Fichier PCAP introuvable."}

    if path.suffix.lower() not in (".pcap", ".pcapng", ".cap"):
        return {
            "error": "Format non supporté. Utilisez PCAP ou PCAPNG."
        }

    report = {
        "file": path.name,
        "size": path.stat().st_size,
        "protocols": [],
        "endpoints": [],
        "conversations": [],
        "packets": [],
        "errors": []
    }

    # Vérification de la capture
    stdout, stderr = run_tshark(
        ["-r", str(path), "-q", "-z", "io,stat,0"]
    )

    if stderr and "error" in stderr.lower():
        report["errors"].append(stderr.strip())

    # Protocoles
    stdout, stderr = run_tshark(
        [
            "-r",
            str(path),
            "-q",
            "-z",
            "io,phs"
        ]
    )

    report["protocols"] = [
        line.strip()
        for line in stdout.splitlines()
        if line.strip()
    ]

    # Endpoints IPv4 / IPv6
    stdout, stderr = run_tshark(
        [
            "-r",
            str(path),
            "-T",
            "fields",
            "-e",
            "ip.src",
            "-e",
            "ip.dst",
            "-e",
            "ipv6.src",
            "-e",
            "ipv6.dst",
            "-E",
            "separator=|"
        ]
    )

    endpoints = set()

    for line in stdout.splitlines():
        parts = line.split("|")

        for value in parts:
            value = value.strip()

            if value:
                endpoints.add(value)

    report["endpoints"] = sorted(endpoints)

    # Conversations TCP / UDP
    for protocol in ("tcp", "udp"):
        stdout, stderr = run_tshark(
            [
                "-r",
                str(path),
                "-q",
                "-z",
                f"conv,{protocol}"
            ]
        )

        if stdout.strip():
            report["conversations"].append({
                "protocol": protocol.upper(),
                "data": stdout.strip()
            })

    # Résumé des paquets
    stdout, stderr = run_tshark(
        [
            "-r",
            str(path),
            "-T",
            "fields",
            "-e",
            "frame.number",
            "-e",
            "frame.time",
            "-e",
            "ip.src",
            "-e",
            "ip.dst",
            "-e",
            "tcp.srcport",
            "-e",
            "tcp.dstport",
            "-e",
            "udp.srcport",
            "-e",
            "udp.dstport",
            "-e",
            "_ws.col.Protocol",
            "-E",
            "separator=|"
        ]
    )

    for line in stdout.splitlines()[:500]:
        parts = line.split("|")

        report["packets"].append({
            "number": parts[0] if len(parts) > 0 else "",
            "time": parts[1] if len(parts) > 1 else "",
            "src": parts[2] or (parts[4] if len(parts) > 4 else ""),
            "dst": parts[3] or (parts[5] if len(parts) > 5 else ""),
            "protocol": parts[8] if len(parts) > 8 else ""
        })

    report["packet_count"] = len(report["packets"])

    report_file = REPORTS / (
        path.stem + "_phonia.json"
    )

    report_file.write_text(
        json.dumps(
            report,
            indent=2,
            ensure_ascii=False
        ),
        encoding="utf-8"
    )

    report["report"] = str(report_file)

    return report


def phonia_page():
    reports = sorted(
        REPORTS.glob("*.json"),
        key=lambda p: p.stat().st_mtime,
        reverse=True
    )[:10]

    history = ""

    for report in reports:
        try:
            data = json.loads(
                report.read_text(encoding="utf-8")
            )

            history += f"""
<div class="card">
    <strong>{escape(data.get("file", report.name))}</strong>
    <p>
        Paquets :
        {escape(str(data.get("packet_count", 0)))}
    </p>
    <p>
        Endpoints :
        {escape(str(len(data.get("endpoints", []))))}
    </p>
</div>
"""

        except Exception:
            continue

    return f"""
<h2>📡 PHONIA NETWORK MINER</h2>

<p>
Analyse forensique de captures réseau PCAP/PCAPNG.
</p>

<form method="post" action="/phonia/analyze">
    <input
        name="file"
        placeholder="/chemin/vers/capture.pcapng"
        required
    >

    <button type="submit">
        ANALYSER LA CAPTURE
    </button>
</form>

<div class="warning">
⚠️ Phonia analyse uniquement une capture déjà présente.
Aucune capture réseau n'est lancée.
</div>

<h3>Derniers rapports</h3>

{history or "<p>Aucun rapport.</p>"}
"""


def phonia_analyze():
    file_path = request.form.get("file", "").strip()

    report = analyze_pcap(file_path)

    if "error" in report:
        result = f"""
<h2>❌ Analyse impossible</h2>
<p>{escape(report["error"])}</p>
"""

    else:
        protocols = "<br>".join(
            escape(x)
            for x in report["protocols"][:40]
        )

        endpoints = "<br>".join(
            escape(x)
            for x in report["endpoints"][:100]
        )

        result = f"""
<h2>📡 PHONIA — RÉSULTAT</h2>

<div class="card">
    <h3>Capture</h3>
    <p>{escape(report["file"])}</p>
    <p>Taille : {report["size"]} octets</p>
    <p>Paquets analysés : {report["packet_count"]}</p>
</div>

<div class="card">
    <h3>🌐 Endpoints</h3>
    {endpoints or "Aucun endpoint IP détecté."}
</div>

<div class="card">
    <h3>📡 Protocoles</h3>
    {protocols or "Aucun protocole détecté."}
</div>

<div class="card">
    <h3>🔄 Conversations</h3>
    <pre>{escape(
        json.dumps(
            report["conversations"],
            indent=2,
            ensure_ascii=False
        )
    )}</pre>
</div>

<div class="card">
    <h3>📄 Rapport</h3>
    <small>{escape(report["report"])}</small>
</div>

<p>
<a href="/phonia">← Nouvelle analyse</a>
</p>
"""

    return result


def list_interfaces():
    """Liste les interfaces disponibles pour une capture locale."""
    stdout, stderr = run_tshark(["-D"], timeout=20)

    interfaces = []
    for line in stdout.splitlines():
        line = line.strip()
        if not line:
            continue

        parts = line.split(". ", 1)
        if len(parts) == 2:
            interfaces.append((parts[0].strip(), parts[1].strip()))

    return interfaces, stderr.strip()


def capture_network(interface, duration):
    """Capture brièvement sur une interface locale puis analyse le PCAP."""
    interfaces, error = list_interfaces()

    allowed = {name for _, name in interfaces}

    if interface not in allowed:
        return {"error": "Interface non autorisée ou inexistante."}

    try:
        duration = int(duration)
    except (TypeError, ValueError):
        duration = 10

    duration = max(1, min(duration, 60))

    CAPTURES.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    capture_file = CAPTURES / f"capture_{timestamp}.pcapng"

    stdout, stderr = run_tshark(
        [
            "-i", interface,
            "-p",
            "-a", f"duration:{duration}",
            "-w", str(capture_file)
        ],
        timeout=duration + 30
    )

    if not capture_file.exists():
        return {
            "error": stderr or stdout or "La capture n'a pas été créée."
        }

    return analyze_pcap(str(capture_file))


def phonia_capture():
    interface = request.form.get("interface", "").strip()
    duration = request.form.get("duration", "10").strip()

    report = capture_network(interface, duration)

    if "error" in report:
        return page("Phonia — Capture", f"""
<h2>❌ Capture impossible</h2>
<p>{escape(report["error"])}</p>
<p><a href="/phonia">← Retour à Phonia</a></p>
""")

    protocols = "<br>".join(
        escape(x) for x in report["protocols"][:40]
    )

    endpoints = "<br>".join(
        escape(x) for x in report["endpoints"][:100]
    )

    return page("Phonia — Capture", f"""
<h2>📡 PHONIA — CAPTURE TERMINÉE</h2>

<div class="card">
    <h3>Capture</h3>
    <p>{escape(report["file"])}</p>
    <p>Taille : {report["size"]} octets</p>
    <p>Paquets analysés : {report["packet_count"]}</p>
</div>

<div class="card">
    <h3>🌐 Endpoints</h3>
    {endpoints or "Aucun endpoint IP détecté."}
</div>

<div class="card">
    <h3>📡 Protocoles</h3>
    {protocols or "Aucun protocole détecté."}
</div>

<div class="card">
    <h3>🔄 Conversations</h3>
    <pre>{escape(json.dumps(
        report["conversations"],
        indent=2,
        ensure_ascii=False
    ))}</pre>
</div>

<div class="card">
    <h3>📄 Rapport</h3>
    <small>{escape(report["report"])}</small>
</div>

<p><a href="/phonia">← Retour à Phonia</a></p>
""")
