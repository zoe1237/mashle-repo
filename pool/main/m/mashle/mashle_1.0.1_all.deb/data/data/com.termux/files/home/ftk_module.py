from pathlib import Path
import hashlib
import json
import subprocess
from datetime import datetime


BASE_DIR = Path.home() / "mashle_ftk"
REPORT_DIR = BASE_DIR / "reports"
REPORT_DIR.mkdir(parents=True, exist_ok=True)


def sha256_file(path):
    h = hashlib.sha256()

    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)

    return h.hexdigest()


def run_cmd(command):
    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=60
        )
        return result.stdout.strip() or result.stderr.strip()
    except Exception as e:
        return str(e)


def ftk_analyze(evidence_path):
    evidence = Path(evidence_path).expanduser().resolve()

    if not evidence.exists():
        raise FileNotFoundError(f"Preuve introuvable : {evidence}")

    if not evidence.is_file():
        raise ValueError("La preuve doit être un fichier.")

    stat = evidence.stat()

    report = {
        "tool": "MASHLE — FTK Imager",
        "mode": "Termux Evidence Inspection",
        "timestamp": datetime.now().isoformat(),
        "evidence": str(evidence),
        "size_bytes": stat.st_size,
        "sha256": sha256_file(evidence),
        "file_type": run_cmd(["file", str(evidence)]),
        "sleuthkit_filesystem": run_cmd(["fsstat", str(evidence)])
    }

    report_path = REPORT_DIR / f"{evidence.stem}_ftk.json"

    report_path.write_text(
        json.dumps(report, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )

    return report, report_path


def ftk_page():
    return """
    <html>
    <head>
        <title>MASHLE — FTK Imager</title>
        <style>
            body {
                background:#0b0b0b;
                color:#eee;
                font-family:Arial,sans-serif;
                padding:30px;
            }

            .box {
                max-width:900px;
                margin:auto;
                background:#151515;
                padding:25px;
                border-radius:12px;
            }

            input, button {
                width:100%;
                box-sizing:border-box;
                padding:12px;
                margin-top:10px;
            }

            button {
                cursor:pointer;
            }

            .info {
                margin-top:20px;
                padding:15px;
                background:#080808;
                border-radius:8px;
            }
        </style>
    </head>

    <body>
        <div class="box">
            <h1>FTK IMAGER</h1>

            <p>
                MASHLE Evidence Inspection
            </p>

            <div class="info">
                Analyse d'une preuve existante :
                hash, taille, type et informations forensic.
            </div>

            <form method="POST" action="/ftk/analyze">
                <input
                    type="text"
                    name="evidence"
                    placeholder="/data/data/com.termux/files/home/mashle_test.img"
                    required
                >

                <button type="submit">
                    ANALYSER LA PREUVE
                </button>
            </form>
        </div>
    </body>
    </html>
    """


def ftk_analyze_route():
    from flask import request
    from markupsafe import escape

    evidence = request.form.get("evidence", "").strip()

    if not evidence:
        return "<h3>Aucune preuve indiquée.</h3>"

    try:
        report, report_path = ftk_analyze(evidence)

        return f"""
        <html>
        <body style="background:#0b0b0b;color:#eee;font-family:Arial;padding:30px">

        <h1>FTK IMAGER — ANALYSE TERMINÉE</h1>

        <p><b>Preuve :</b> {escape(report["evidence"])}</p>
        <p><b>Taille :</b> {report["size_bytes"]} octets</p>
        <p><b>SHA-256 :</b> {report["sha256"]}</p>

        <h2>Type</h2>
        <pre>{escape(report["file_type"])}</pre>

        <h2>Système de fichiers</h2>
        <pre>{escape(report["sleuthkit_filesystem"][:12000])}</pre>

        <p>
            <b>Rapport :</b> {escape(str(report_path))}
        </p>

        <p><a href="/ftk">← Retour</a></p>

        </body>
        </html>
        """

    except Exception as e:
        return f"""
        <html>
        <body style="background:#0b0b0b;color:#eee;font-family:Arial;padding:30px">
        <h1>ERREUR FTK IMAGER</h1>
        <pre>{escape(str(e))}</pre>
        </body>
        </html>
        """
