from flask import request
from markupsafe import escape
import subprocess
from pathlib import Path
import json
from datetime import datetime

DOWNLOADS = Path.home() / "storage" / "downloads"
RULES = Path.home() / "mashle_rules.yar"
HISTORY = Path.home() / "mashle_yara_history.json"


def load_history():
    if HISTORY.exists():
        try:
            return json.loads(HISTORY.read_text(encoding="utf-8"))
        except Exception:
            return []
    return []


def save_history(data):
    HISTORY.write_text(
        json.dumps(data, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )


def yara_page():
    selected = request.args.get("file", "").strip()
    result = None
    error = None

    files = []
    if DOWNLOADS.exists():
        files = sorted(
            [p for p in DOWNLOADS.iterdir() if p.is_file()],
            key=lambda p: p.name.lower()
        )

    if selected:
        path = DOWNLOADS / selected

        try:
            path.resolve().relative_to(DOWNLOADS.resolve())
        except ValueError:
            error = "Fichier non autorisé."
        else:
            if not path.is_file():
                error = "Fichier introuvable."
            elif not RULES.is_file():
                error = "Règles YARA introuvables."
            else:
                try:
                    process = subprocess.run(
                        ["yara", str(RULES), str(path)],
                        capture_output=True,
                        text=True,
                        timeout=20
                    )

                    output = process.stdout.strip()

                    if output:
                        result = {
                            "status": "Correspondance détectée",
                            "matches": output.splitlines()
                        }
                    else:
                        result = {
                            "status": "Aucune correspondance",
                            "matches": []
                        }

                    history = load_history()
                    history.insert(0, {
                        "file": path.name,
                        "status": result["status"],
                        "matches": result["matches"],
                        "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    })
                    save_history(history[:50])

                except subprocess.TimeoutExpired:
                    error = "Analyse interrompue : délai dépassé."
                except Exception as e:
                    error = str(e)

    options = "".join(
        f'<option value="{escape(p.name)}" '
        f'{"selected" if p.name == selected else ""}>'
        f'{escape(p.name)}</option>'
        for p in files
    )

    output = ""

    if result:
        status = result["status"]

        output += f"""
        <div class="card" style="margin-top:20px;">
            <h3>{escape(status)}</h3>
            <p><strong>Fichier :</strong> {escape(selected)}</p>
        """

        if result["matches"]:
            output += "<p><strong>Règles déclenchées :</strong></p><ul>"
            for match in result["matches"]:
                output += f"<li>{escape(match)}</li>"
            output += "</ul>"
        else:
            output += "<p>Aucune règle n'a correspondu au fichier.</p>"

        output += "</div>"

    if error:
        output = f"""
        <div class="card" style="margin-top:20px;">
            <h3>Erreur</h3>
            <p>{escape(error)}</p>
        </div>
        """

    history = load_history()

    history_html = ""

    if history:
        rows = ""

        for item in history[:15]:
            matches = ", ".join(item.get("matches", []))
            rows += f"""
            <tr>
                <td>{escape(item.get("date", ""))}</td>
                <td>{escape(item.get("file", ""))}</td>
                <td>{escape(item.get("status", ""))}</td>
                <td>{escape(matches or "—")}</td>
            </tr>
            """

        history_html = f"""
        <h3 style="margin-top:35px;">Historique</h3>

        <table>
            <tr>
                <th>Date</th>
                <th>Fichier</th>
                <th>Résultat</th>
                <th>Règle</th>
            </tr>
            {rows}
        </table>
        """

    return f"""
    <h2>YARA</h2>
    <p>Analyse locale avec les règles MASHLE.</p>

    <div class="card">
        <p><strong>Règles actives :</strong> {escape(RULES.name)}</p>

        <form method="get">
            <select name="file" style="width:80%;max-width:700px;">
                <option value="">— Sélectionner un fichier —</option>
                {options}
            </select>

            <button type="submit">Analyser</button>
        </form>
    </div>

    {output}
    {history_html}
    """
