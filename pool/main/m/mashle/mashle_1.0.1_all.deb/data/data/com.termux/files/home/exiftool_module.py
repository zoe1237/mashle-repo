from flask import request
from markupsafe import escape
import subprocess
from pathlib import Path

DOWNLOADS = Path.home() / "storage" / "downloads"


def exiftool_page():
    selected = request.args.get("file", "").strip()
    result = None
    error = None

    files = []
    if DOWNLOADS.exists():
        files = sorted(
            [p for p in DOWNLOADS.iterdir() if p.is_file()],
            key=lambda p: p.name.lower()
        )

    if selected:
        path = DOWNLOADS / selected

        # Empêche de sortir du dossier Downloads
        try:
            path.resolve().relative_to(DOWNLOADS.resolve())
        except ValueError:
            error = "Fichier non autorisé."
        else:
            if not path.is_file():
                error = "Fichier introuvable."
            else:
                try:
                    p = subprocess.run(
                        ["exiftool", str(path)],
                        capture_output=True,
                        text=True,
                        timeout=15
                    )
                    result = p.stdout if p.returncode == 0 else p.stderr
                except Exception as e:
                    error = str(e)

    options = "".join(
        f'<option value="{escape(p.name)}" '
        f'{"selected" if p.name == selected else ""}>'
        f'{escape(p.name)}</option>'
        for p in files
    )

    output = ""
    if result:
        output = f"""
        <h3>Métadonnées</h3>
        <pre style="
            white-space:pre-wrap;
            background:#191b20;
            border:1px solid #30333a;
            padding:18px;
            border-radius:12px;
            overflow:auto;
        ">{escape(result)}</pre>
        """

    if error:
        output = f'<p style="color:#ff7777;">{escape(error)}</p>'

    return f"""
    <h2>ExifTool</h2>
    <p>Analyse locale des métadonnées des fichiers.</p>

    <form method="get">
        <select name="file" style="width:80%;max-width:700px;">
            <option value="">— Sélectionner un fichier —</option>
            {options}
        </select>
        <button type="submit">Analyser</button>
    </form>

    {output}
    """
