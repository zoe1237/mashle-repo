from pathlib import Path
from flask import request
from markupsafe import escape
import json
import subprocess

PCAP_DIR = Path.home() / "mashle_wireshark"
REPORT_DIR = PCAP_DIR / "reports"
REPORT_DIR.mkdir(parents=True, exist_ok=True)


def run_tshark(args, timeout=120):
    try:
        result = subprocess.run(
            ["tshark"] + args,
            capture_output=True,
            text=True,
            timeout=timeout
        )
        return result.stdout, result.stderr
    except Exception as e:
        return "", str(e)


def analyze_pcap(file_path, display_filter=""):
    path = Path(file_path).expanduser()

    if not path.exists():
        return {"error": "Fichier introuvable."}

    if path.suffix.lower() not in (".pcap", ".pcapng", ".cap"):
        return {"error": "Format non pris en charge."}

    args = ["-r", str(path), "-T", "fields",
            "-e", "frame.number",
            "-e", "frame.time",
            "-e", "ip.src",
            "-e", "ip.dst",
            "-e", "tcp.srcport",
            "-e", "tcp.dstport",
            "-e", "_ws.col.Protocol",
            "-e", "frame.len"]

    if display_filter:
        args.extend(["-Y", display_filter])

    stdout, stderr = run_tshark(args)

    if not stdout.strip() and stderr.strip():
        return {"error": stderr.strip()}

    packets = []

    for line in stdout.splitlines():
        fields = line.split("\t")
        while len(fields) < 8:
            fields.append("")

        packets.append({
            "number": fields[0],
            "time": fields[1],
            "source": fields[2],
            "destination": fields[3],
            "src_port": fields[4],
            "dst_port": fields[5],
            "protocol": fields[6],
            "length": fields[7]
        })

    report = {
        "file": path.name,
        "path": str(path),
        "filter": display_filter,
        "packet_count": len(packets),
        "packets": packets[:500]
    }

    report_path = REPORT_DIR / f"{path.stem}_wireshark.json"
    report_path.write_text(
        json.dumps(report, indent=2, ensure_ascii=False)
    )

    return {
        "report": report,
        "report_path": str(report_path)
    }


def wireshark_page():
    return """
<h2>🦈 WIRESHARK / PCAP</h2>

<p>
Analyse détaillée des paquets à partir d'une capture PCAP ou PCAPNG.
</p>

<form method="post" action="/wireshark/analyze">
    <input
        name="file"
        placeholder="/chemin/vers/capture.pcapng"
        required
    >

    <input
        name="filter"
        placeholder="Filtre Wireshark, ex: tcp"
    >

    <button type="submit">
        ANALYSER LES PAQUETS
    </button>
</form>

<div class="warning">
⚠️ Analyse hors ligne : aucun fichier n'est exécuté.
</div>
"""


def wireshark_analyze():
    file_path = request.form.get("file", "").strip()
    display_filter = request.form.get("filter", "").strip()

    result = analyze_pcap(file_path, display_filter)

    if "error" in result:
        return f"""
<h2>❌ Analyse impossible</h2>
<p>{escape(result["error"])}</p>
<p><a href="/wireshark">← Retour</a></p>
"""

    report = result["report"]

    rows = ""

    for packet in report["packets"]:
        rows += f"""
<tr>
<td>{escape(packet["number"])}</td>
<td>{escape(packet["source"] or "—")}</td>
<td>{escape(packet["destination"] or "—")}</td>
<td>{escape(packet["src_port"] or "—")}</td>
<td>{escape(packet["dst_port"] or "—")}</td>
<td>{escape(packet["protocol"] or "—")}</td>
<td>{escape(packet["length"] or "—")}</td>
</tr>
"""

    return f"""
<h2>🦈 WIRESHARK — RÉSULTAT</h2>

<div class="card">
<h3>📦 Capture</h3>
<p>{escape(report["file"])}</p>
<p>Paquets : {report["packet_count"]}</p>
<p>Filtre : {escape(report["filter"] or "Aucun")}</p>
</div>

<div class="card">
<h3>🔎 Paquets</h3>

<div style="overflow-x:auto">
<table>
<tr>
<th>#</th>
<th>Source</th>
<th>Destination</th>
<th>Port source</th>
<th>Port destination</th>
<th>Protocole</th>
<th>Taille</th>
</tr>
{rows}
</table>
</div>
</div>

<div class="card">
<h3>📄 Rapport</h3>
<small>{escape(result["report_path"])}</small>
</div>

<p>
<a href="/wireshark">← Nouvelle analyse</a>
</p>
"""


print("Module Wireshark créé.")
